// This class is not used in the project yet.
class Text {
  // The constructor has three parameters. Here is an example of how you would create
  // an instance of this class
  constructor(root, xPos, yPos, size) {
    // We create a DOM element, set its CSS attributes then append it to the parent DOM element. We also
    // set the \`domElement\` property of the instance to the newly created DOM element so we can update it later
    this.div = document.createElement('div');

    this.div.style.position = 'absolute';
    this.div.style.left = xPos;
    this.div.style.top = yPos;
    this.div.style.color = 'rgb(75, 213, 238)';
    this.div.style.font = ` ${size}px Century Gothic`;
    this.div.style.zIndex = 2000;
    

    root.appendChild(this.div);

    this.domElement =this.div;
  }

  // This method is used to update the text displayed in the DOM element
  update(txt) { 
    this.domElement.innerText = txt;
  
  }
}
