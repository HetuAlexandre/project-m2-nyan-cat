# Instructions

1. Delete this file before pushing to the cohort org.
2. You may remove, or not, the `images/inspirations` folder. It contains screenshots of past project submissions. They can be shown in class instead of being provided here.
3. Alter the README to contain specific submission guidelines. (esp. due date)
